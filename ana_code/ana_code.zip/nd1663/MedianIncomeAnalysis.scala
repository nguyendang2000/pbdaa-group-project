{
    def getMax(rdd: org.apache.spark.rdd.RDD[String]) : String = {
        rdd.collect().reduce((prev, curr) => {
            if(prev.split(",")(1).toInt > curr.split(",")(1).toInt) {
                prev
            }
            else {
                curr
            }
        })
    }

    def getMin(rdd: org.apache.spark.rdd.RDD[String]) : String = {
        rdd.collect().reduce((prev, curr) => {
            if(prev.split(",")(1).toInt < curr.split(",")(1).toInt) {
                prev
            }
            else {
                curr
            }
        })
    }

    def annotateZipCode(zip: String) : String = {
        val zipInt = zip.toInt
        if(zipInt >= 10001 && zipInt <= 10282) {
            "Manhattan"
        }
        else if(zipInt >= 10301 && zipInt <= 10314) {
            "Staten Island"
        }
        else if(zipInt >= 10451 && zipInt <= 10475) {
            "Bronx"
        }
        else if((zipInt >= 11004 && zipInt <= 11109) || (zipInt >= 11351 && zipInt <= 11697)) {
            "Queens"
        }
        else {
            "Brooklyn"
        }
    }

    def getMinNoZeros(rdd: org.apache.spark.rdd.RDD[String]) : String = {
        rdd.collect().reduce((prev, curr) => {
            if(curr.split(",")(1).toInt == 0 || curr.split(",")(1).toInt == -1 || prev.split(",")(1).toInt < curr.split(",")(1).toInt) {
                prev
            }
            else {
                curr
            }
        })
    }

    println("NYC 2020 MEDIAN INCOME DATA ANALYSIS")

    val csvFile = sc.textFile("/user/nd1663/project/datasets/median_income_clean.csv")

    val headerRow = csvFile.first()

    val noHeader = csvFile.filter(row => !row.equals(headerRow))

    val boroughAdded = noHeader.map(row => row.concat("," + annotateZipCode(row.split(",")(0))))

    val householdCounts = boroughAdded.map(row => row.split(",")(0) + "," + row.split(",")(1) + "," + row.split(",")(2) + "," + row.split(",")(81))

    println("Total number of NYC households: " + boroughAdded.map(row => row.split(",")(1).toInt).sum().toInt)

    val populationByBorough = boroughAdded.map(row => (row.split(",")(81), row.split(",")(1).toInt)).reduceByKey((prev, next) => prev + next)
    populationByBorough.collect().foreach(println)

    val maxHouseholds = getMax(householdCounts)

    println(f"\nZip code with largest number of households: ${maxHouseholds.split(",")(0)} in ${maxHouseholds.split(",")(3)} (${maxHouseholds.split(",")(1)} households) - Median income: ${maxHouseholds.split(",")(2)} dollars")

    val minHouseholds = getMin(householdCounts)

    println(f"Zip code with smallest number of households: ${minHouseholds.split(",")(0)} in ${minHouseholds.split(",")(3)} (${minHouseholds.split(",")(1)} households) - Median income: ${minHouseholds.split(",")(2)} dollars")

    val minHouseholdsNoZeros = getMinNoZeros(householdCounts)

    println(f"Zip code with smallest number of households with 0s excluded: ${minHouseholdsNoZeros.split(",")(0)} in ${minHouseholdsNoZeros.split(",")(3)} (${minHouseholdsNoZeros.split(",")(1)} households) - Median income: ${minHouseholdsNoZeros.split(",")(2)} dollars")

    val zeroHouseholds = householdCounts.filter(row => row.split(",")(1).toInt == 0)
    println("Zip codes with zero households " + "(" + zeroHouseholds.count() + "): ")
    zeroHouseholds.collect().foreach(row => print(row.split(",")(0) + "\t"))
    println("\n")

    val householdIncomes = boroughAdded.map(row => row.split(",")(0) + "," + row.split(",")(2) + "," + row.split(",")(1) + "," + row.split(",")(81))

    val maxIncome = getMax(householdIncomes)

    println(f"Zip code with highest median income: ${maxIncome.split(",")(0)} in ${maxIncome.split(",")(3)} (${maxIncome.split(",")(1)} dollars) - ${maxIncome.split(",")(2)} households")

    val maxIncomeCount = householdIncomes.filter(row => row.split(",")(1).toInt == 250000)
    println("Zip codes with highest median income of 250,000+ " + "(" + maxIncomeCount.count() + "): ")
    maxIncomeCount.collect().foreach(row => print(f"${row.split(",")(0)} (${row.split(",")(3)}) \t"))
    print("\n")

    val minIncome = getMin(householdIncomes)
    println(f"Zip code with lowest median income: ${minIncome.split(",")(0)} in ${minIncome.split(",")(3)} (${minIncome.split(",")(1)} dollars) - ${minIncome.split(",")(2)} households")

    val minIncomeNoZeros = getMinNoZeros(householdIncomes)
    println(f"Zip code with lowest available median income data: ${minIncomeNoZeros.split(",")(0)} in ${minIncomeNoZeros.split(",")(3)} (${minIncomeNoZeros.split(",")(1)} dollars) - ${minIncomeNoZeros.split(",")(2)} households")

    var householdCountSorted = householdCounts.filter(row => row.split(",")(1).toInt != 0).sortBy(row => row.split(",")(1).toInt).collect()
    println("\n10 zip codes with lowest number of households:")
    householdCountSorted.take(10).foreach(row => println(f"${row.split(",")(0)}${" "*5}${row.split(",")(3)}${" "*(13-row.split(",")(3).length)}${row.split(",")(1)}${" "*(6-row.split(",")(1).toString.length)}households${" "*5}${row.split(",")(2)}${" "*(7-row.split(",")(2).toString.length)}dollars"))
    householdCountSorted = householdCountSorted.filter(row => row.split(",")(2).toInt != -1)
    println("\n10 zip codes with lowest number of households (with available income data):")
    householdCountSorted.take(10).foreach(row => println(f"${row.split(",")(0)}${" "*5}${row.split(",")(3)}${" "*(13-row.split(",")(3).length)}${row.split(",")(1)}${" "*(6-row.split(",")(1).toString.length)}households${" "*5}${row.split(",")(2)}${" "*(7-row.split(",")(2).toString.length)}dollars"))
    println("\n10 zip codes with highest number of households:")
    householdCountSorted.takeRight(10).foreach(row => println(f"${row.split(",")(0)}${" "*5}${row.split(",")(3)}${" "*(13-row.split(",")(3).length)}${row.split(",")(1)}${" "*(6-row.split(",")(1).toString.length)}households${" "*5}${row.split(",")(2)}${" "*(7-row.split(",")(2).toString.length)}dollars"))

    val medianIncomeSorted = householdIncomes.filter(row => row.split(",")(1).toInt != -1).sortBy(row => row.split(",")(1).toInt).collect()
    println("\n10 zip codes with lowest median income:")
    medianIncomeSorted.take(10).foreach(row => println(f"${row.split(",")(0)}${" "*3}${row.split(",")(3)}${" "*(13-row.split(",")(3).length)}${row.split(",")(1)}${" "*(8-row.split(",")(1).toString.length)}dollars${" "*5}${row.split(",")(2)}${" "*(6-row.split(",")(2).toString.length)}households"))
    println("\n10 zip codes with highest median income:")
    medianIncomeSorted.takeRight(10).foreach(row => println(f"${row.split(",")(0)}${" "*3}${row.split(",")(3)}${" "*(13-row.split(",")(3).length)}${row.split(",")(1)}${" "*(8-row.split(",")(1).toString.length)}dollars${" "*5}${row.split(",")(2)}${" "*(6-row.split(",")(2).toString.length)}households"))


    println("\nMedian income of zip codes divided into brackets:")

    val sortedBrackets = boroughAdded.map(row => {
        val income = row.split(",")(2).toInt
        if(income == -1) {
            ("NO DATA",1)
        }
        else if(income <= 10275) {
            ("$0 to $10275",1)
        }
        else if(income <= 41775) {
            ("$10276 to $41775",1)
        }
        else if(income <= 89075) {
            ("$41776 to $89075",1)
        }
        else if(income <= 170050) {
            ("$89076 to $170050",1)
        }
        else if(income <= 215950) {
            ("$170051 to $215950",1)
        }
        else {
            ("$215951 to $539900",1)
        }
    }).reduceByKey((x, y) => x + y).collect().foreach(row => {
        val string = row.toString.substring(1, row.toString.length - 1)
        println(f"${string.split(",")(0)}: ${string.split(",")(1)}")
    })
}